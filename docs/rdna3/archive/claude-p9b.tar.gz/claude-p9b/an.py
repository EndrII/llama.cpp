import csv,glob,collections,statistics as st,sys
d=sys.argv[1]
rows=[r for r in csv.DictReader(open(glob.glob(d+'/run_kernel_trace.csv')[0])) if 'rocclr' not in r['Kernel_Name']]
rows.sort(key=lambda r:int(r['Start_Timestamp']))
heads=[i for i,r in enumerate(rows) if r['Kernel_Name'].startswith('void mul_mat_vec_q<(ggml_type)14')]
N=100; cat=collections.defaultdict(lambda:[0,0.0,'']); wall=[];busy=[];nk=[]
def cl(n,p):
    n=n.replace('(anonymous namespace)::','')
    if n.startswith('void mul_mat_vec_q<(ggml_type)14'): return 'head'
    if 'k_mv<1, true, false' in n: return 'gate_up'
    if 'k_mv<1, false, true, false, false, false' in n: return 'down' if 'k_mv<1, true' in p else 'ssm_out' if 'gated_delta' in p else 'attn_out' if 'flash' in p else 'rot_other'
    if 'k_mv<1, false, false, true, true' in n: return 'gdn_qkvz'
    if 'k_mv<1, false, false, false, false, true' in n: return 'attn_qkv'
    if 'k_rmsnorm_rot' in n: return 'rmsnorm'
    if 'gated_delta' in n: return 'gdn_rec'
    if 'flash_attn' in n: return 'attn_tile'
    if 'k_attn_prep' in n: return 'attn_prep'
    return 'tail'
for a,b in zip(heads[-N-1:-1],heads[-N:]):
    wall.append((int(rows[b]['Start_Timestamp'])-int(rows[a]['Start_Timestamp']))/1e3); s=0
    for i in range(a,b):
        r=rows[i]; p=rows[i-1]['Kernel_Name'].replace('(anonymous namespace)::','') if i>a else ''
        t=(int(r['End_Timestamp'])-int(r['Start_Timestamp']))/1e3; c=cl(r['Kernel_Name'],p); cat[c][0]+=1; cat[c][1]+=t; cat[c][2]='grid=%sx%s vgpr=%s'%(r['Grid_Size_X'],r['Grid_Size_Y'],r['VGPR_Count']); s+=t
    busy.append(s); nk.append(b-a)
W=st.median(wall); B=st.median(busy)
print(f'launches {st.median(nk):.0f}  wall {W:.0f} us  busy {B:.0f} us  gaps {W-B:.0f} us ({100*(W-B)/W:.0f}%)')
for k,(c,t,g) in sorted(cat.items(),key=lambda x:-x[1][1]): print(f'{k:10s} {c/N:5.0f}/tok {t/c:7.2f} us/call {t/N:7.0f} us/tok {100*t/N/B:5.1f}%  {g}')
